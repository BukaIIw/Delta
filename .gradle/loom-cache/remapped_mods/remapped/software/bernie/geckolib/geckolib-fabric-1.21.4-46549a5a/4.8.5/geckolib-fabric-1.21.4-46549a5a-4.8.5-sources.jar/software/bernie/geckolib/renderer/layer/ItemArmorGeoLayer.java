package software.bernie.geckolib.renderer.layer;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.GeckoLibServices;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.cache.object.GeoCube;
import software.bernie.geckolib.object.Color;
import software.bernie.geckolib.renderer.GeoArmorRenderer;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.service.GeckoLibClient;
import software.bernie.geckolib.util.RenderUtil;

import java.util.function.Function;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.SkullBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPart.Cuboid;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.SkullBlockEntityModel;
import net.minecraft.client.render.block.entity.SkullBlockEntityRenderer;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.equipment.EquipmentRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Util;

/**
 * Builtin class for handling dynamic armor rendering on GeckoLib entities
 * <p>
 * Supports both {@link GeoItem GeckoLib} and {@link ArmorItem Vanilla} armor models
 * <p>
 * Unlike a traditional armor renderer, this renderer renders per-bone, giving much more flexible armor rendering
 */
public class ItemArmorGeoLayer<T extends LivingEntity & GeoAnimatable> extends GeoRenderLayer<T> {
	protected final EquipmentRenderer equipmentRenderer;
	protected final Function<SkullBlock.SkullType, SkullBlockEntityModel> skullModels;

	@Nullable
	protected ItemStack mainHandStack;
	@Nullable protected ItemStack offhandStack;
	@Nullable protected ItemStack helmetStack;
	@Nullable protected ItemStack chestplateStack;
	@Nullable protected ItemStack leggingsStack;
	@Nullable protected ItemStack bootsStack;

	public ItemArmorGeoLayer(GeoRenderer<T> geoRenderer, EquipmentRenderer equipmentLayerRenderer) {
		super(geoRenderer);

		this.equipmentRenderer = equipmentLayerRenderer;
		this.skullModels = Util.memoize(type -> SkullBlockEntityRenderer.getModels(MinecraftClient.getInstance().getLoadedEntityModels(), type));
	}

	/**
	 * Return an EquipmentSlot for a given {@link ItemStack} and animatable instance
	 * <p>
	 * This is what determines the base model to use for rendering a particular stack
	 */
	@NotNull
	protected EquipmentSlot getEquipmentSlotForBone(GeoBone bone, ItemStack stack, T animatable) {
		for (EquipmentSlot slot : EquipmentSlot.values()) {
			if (slot.getType() == EquipmentSlot.Type.HUMANOID_ARMOR) {
				if (stack == animatable.getEquippedStack(slot))
					return slot;
			}
		}

		return EquipmentSlot.CHEST;
	}

	/**
	 * Return a ModelPart for a given {@link GeoBone}
	 * <p>
	 * This is then transformed into position for the final render
	 */
	@NotNull
	protected ModelPart getModelPartForBone(GeoBone bone, EquipmentSlot slot, ItemStack stack, T animatable, BipedEntityModel<?> baseModel) {
		return baseModel.body;
	}

	/**
	 * Get the {@link ItemStack} relevant to the bone being rendered
	 *
	 * @return The ItemStack for the bone being rendered, or null if this bone should be ignored
	 */
	@Nullable
	protected ItemStack getArmorItemForBone(GeoBone bone, T animatable) {
		return null;
	}

	/**
	 * This method is called by the {@link GeoRenderer} before rendering, immediately after {@link GeoRenderer#preRender} has been called
	 * <p>
	 * This allows for RenderLayers to perform pre-render manipulations such as hiding or showing bones
	 */
	@Override
	public void preRender(MatrixStack poseStack, T animatable, BakedGeoModel bakedModel, @Nullable RenderLayer renderType, VertexConsumerProvider bufferSource,
                          @Nullable VertexConsumer buffer, float partialTick, int packedLight, int packedOverlay, int renderColor) {
		this.mainHandStack = animatable.getEquippedStack(EquipmentSlot.MAINHAND);
		this.offhandStack = animatable.getEquippedStack(EquipmentSlot.OFFHAND);
		this.helmetStack = animatable.getEquippedStack(EquipmentSlot.HEAD);
		this.chestplateStack = animatable.getEquippedStack(EquipmentSlot.CHEST);
		this.leggingsStack = animatable.getEquippedStack(EquipmentSlot.LEGS);
		this.bootsStack = animatable.getEquippedStack(EquipmentSlot.FEET);
	}

	/**
	 * This method is called by the {@link GeoRenderer} for each bone being rendered
	 * <p>
	 * This is a more expensive call, particularly if being used to render something on a different buffer<br>
	 * It does however have the benefit of having the matrix translations and other transformations already applied from render-time<br>
	 * It's recommended to avoid using this unless necessary
	 * <p>
	 * The {@link GeoBone} in question has already been rendered by this stage
	 * <p>
	 * If you <i>do</i> use it, and you render something that changes the {@link VertexConsumer buffer}, you need to reset it back to the previous buffer
	 * using {@link VertexConsumerProvider#getBuffer} before ending the method
	 */
	@Override
	public void renderForBone(MatrixStack poseStack, T animatable, GeoBone bone, RenderLayer renderType, VertexConsumerProvider bufferSource,
							  VertexConsumer buffer, float partialTick, int packedLight, int packedOverlay, int renderColor) {
		ItemStack armorStack = getArmorItemForBone(bone, animatable);

		if (armorStack == null || armorStack.isEmpty())
			return;

		if (armorStack.getItem() instanceof BlockItem blockItem && blockItem.getBlock() instanceof AbstractSkullBlock skullBlock) {
			renderSkullAsArmor(poseStack, bone, armorStack, skullBlock, bufferSource, packedLight);
		}
		else {
			EquipmentSlot slot = getEquipmentSlotForBone(bone, armorStack, animatable);
			BipedEntityModel<?> model = getModelForItem(bone, slot, armorStack, animatable);
			ModelPart modelPart = getModelPartForBone(bone, slot, armorStack, animatable, model);

			if (!modelPart.cuboids.isEmpty()) {
				poseStack.push();
				poseStack.scale(-1, -1, 1);

				if (model instanceof GeoArmorRenderer<?> geoArmorRenderer) {
					prepModelPartForRender(poseStack, bone, modelPart);
					geoArmorRenderer.prepForRender(animatable, armorStack, slot, model, bufferSource, partialTick, 0, 0);
					geoArmorRenderer.applyBoneVisibilityByPart(slot, modelPart, model);
					geoArmorRenderer.render(poseStack, null, packedLight, packedOverlay, Color.WHITE.argbInt());
				}
				else {
					EquippableComponent equippable = armorStack.get(DataComponentTypes.EQUIPPABLE);

					if (equippable != null) {
						equippable.assetId().ifPresent(modelPath -> {
							prepModelPartForRender(poseStack, bone, modelPart);
							renderVanillaArmorPiece(poseStack, animatable, bone, slot, armorStack, equippable, modelPath, model, modelPart, bufferSource, partialTick, packedLight, packedOverlay);
						});
					}
				}

				poseStack.pop();
			}
		}
	}

	/**
	 * Renders an individual armor piece base on the given {@link GeoBone} and {@link ItemStack}
	 */
	protected void renderVanillaArmorPiece(MatrixStack poseStack, T animatable, GeoBone bone, EquipmentSlot slot, ItemStack armorStack,
										   EquippableComponent equippable, RegistryKey<EquipmentAsset> equipmentAsset, BipedEntityModel<?> model, ModelPart modelPart,
										   VertexConsumerProvider bufferSource, float partialTick, int packedLight, int packedOverlay) {
		EquipmentModel.LayerType layerType = slot == EquipmentSlot.LEGS ? EquipmentModel.LayerType.HUMANOID_LEGGINGS : EquipmentModel.LayerType.HUMANOID;

		setVanillaModelPartVisibility(animatable, armorStack, bone, model, modelPart, slot, partialTick);
		this.equipmentRenderer.render(layerType, equipmentAsset, model, armorStack, poseStack, bufferSource, packedLight);
	}

	/**
	 * @deprecated Use {@link #setVanillaModelPartVisibility(LivingEntity, ItemStack, GeoBone, BipedEntityModel, ModelPart, EquipmentSlot, float)}
	 */
	@Deprecated(forRemoval = true)
	protected void setVanillaModelPartVisibility(BipedEntityModel<?> baseModel, EquipmentSlot slot) {}

	/**
	 * Spiritual replica of {@link net.minecraft.client.render.entity.feature.ArmorFeatureRenderer#setVisible(BipedEntityModel, EquipmentSlot)}.
	 * <p>
	 * Hide all non-relevant parts for the armor-player model, so it only renders the correct one.
	 * <p>
	 * Because GeckoLib models rely on per-bone rendering for armour part alignment, for the most part we just hide all model parts except the one we've specifically called to render
	 */
	protected void setVanillaModelPartVisibility(T animatable, ItemStack armorStack, GeoBone bone, BipedEntityModel<?> baseModel, ModelPart modelPart, EquipmentSlot slot, float partialTick) {
		baseModel.setVisible(false);
		modelPart.visible = true;
	}

	/**
	 * Returns a cached instance of a base HumanoidModel that is used for rendering/modelling the provided {@link ItemStack}
	 */
	@NotNull
	protected BipedEntityModel<?> getModelForItem(GeoBone bone, EquipmentSlot slot, ItemStack stack, T animatable) {
		BipedEntityModel<BipedEntityRenderState> defaultModel = slot == EquipmentSlot.LEGS ? GeckoLibClient.GENERIC_INNER_ARMOR_MODEL.get() : GeckoLibClient.GENERIC_OUTER_ARMOR_MODEL.get();
		Model model = GeckoLibServices.Client.ITEM_RENDERING.getArmorModelForItem(animatable, getRenderer() instanceof GeoEntityRenderer<T> entityRenderer && entityRenderer.getEntityRenderState() instanceof BipedEntityRenderState renderState ? renderState : new BipedEntityRenderState(), stack, slot, slot == EquipmentSlot.LEGS ? EquipmentModel.LayerType.HUMANOID_LEGGINGS : EquipmentModel.LayerType.HUMANOID, defaultModel);

		return model instanceof BipedEntityModel<?> humanoidModel ? humanoidModel : defaultModel;
	}

	/**
	 * Render a given {@link AbstractSkullBlock} as a worn armor piece in relation to a given {@link GeoBone}
	 */
	protected void renderSkullAsArmor(MatrixStack poseStack, GeoBone bone, ItemStack stack, AbstractSkullBlock skullBlock, VertexConsumerProvider bufferSource, int packedLight) {
		SkullBlock.SkullType type = skullBlock.getSkullType();
		SkullBlockEntityModel model = this.skullModels.apply(type);
		RenderLayer renderType = SkullBlockEntityRenderer.getRenderLayer(type, stack.get(DataComponentTypes.PROFILE));

		poseStack.push();
		RenderUtil.translateAndRotateMatrixForBone(poseStack, bone);
		poseStack.scale(1.1875f, 1.1875f, 1.1875f);
		poseStack.translate(-0.5f, 0, -0.5f);
		SkullBlockEntityRenderer.renderSkull(null, 0, 0, poseStack, bufferSource, packedLight, model, renderType);
		poseStack.pop();
	}

	/**
	 * Prepares the given {@link ModelPart} for render by setting its translation, position, and rotation values based on the provided {@link GeoBone}
	 * <p>
	 * This implementation uses the <b><u>FIRST</u></b> cube in the source part
	 * to determine the scale and position of the GeoArmor to be rendered
	 *
	 * @param poseStack The PoseStack being used for rendering
	 * @param bone The GeoBone to base the translations on
	 * @param sourcePart The ModelPart to translate
	 */
	protected void prepModelPartForRender(MatrixStack poseStack, GeoBone bone, ModelPart sourcePart) {
		final GeoCube firstCube = bone.getCubes().getFirst();
		final Cuboid armorCube = sourcePart.cuboids.getFirst();
		final double armorBoneSizeX = firstCube.size().getX();
		final double armorBoneSizeY = firstCube.size().getY();
		final double armorBoneSizeZ = firstCube.size().getZ();
		final double actualArmorSizeX = Math.abs(armorCube.maxX - armorCube.minX);
		final double actualArmorSizeY = Math.abs(armorCube.maxY - armorCube.minY);
		final double actualArmorSizeZ = Math.abs(armorCube.maxZ - armorCube.minZ);
		float scaleX = (float)(armorBoneSizeX / actualArmorSizeX);
		float scaleY = (float)(armorBoneSizeY / actualArmorSizeY);
		float scaleZ = (float)(armorBoneSizeZ / actualArmorSizeZ);

		sourcePart.setPivot(-(bone.getPivotX() - ((bone.getPivotX() * scaleX) - bone.getPivotX()) / scaleX),
				-(bone.getPivotY() - ((bone.getPivotY() * scaleY) - bone.getPivotY()) / scaleY),
				(bone.getPivotZ() - ((bone.getPivotZ() * scaleZ) - bone.getPivotZ()) / scaleZ));

		sourcePart.pitch = -bone.getRotX();
		sourcePart.yaw = -bone.getRotY();
		sourcePart.roll = bone.getRotZ();

		poseStack.scale(scaleX, scaleY, scaleZ);
	}
}
