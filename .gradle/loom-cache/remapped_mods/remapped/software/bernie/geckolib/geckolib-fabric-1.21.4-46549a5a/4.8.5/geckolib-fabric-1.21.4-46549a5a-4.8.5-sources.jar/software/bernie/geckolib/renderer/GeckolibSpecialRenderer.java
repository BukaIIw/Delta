package software.bernie.geckolib.renderer;

import com.mojang.serialization.MapCodec;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.LoadedEntityModels;
import net.minecraft.client.render.item.model.special.SpecialModelRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;

public class GeckolibSpecialRenderer implements SpecialModelRenderer<GeckolibSpecialRenderer.RenderData> {
    @Override
    public void render(@Nullable GeckolibSpecialRenderer.RenderData renderData, ModelTransformationMode itemDisplayContext, MatrixStack poseStack, VertexConsumerProvider bufferSource, int packedLight, int packedOverlay, boolean hasGlint) {
        GeoRenderProvider.of(renderData.item).getGeoItemRenderer().render(renderData, itemDisplayContext, poseStack, bufferSource, packedLight, packedOverlay, hasGlint);
    }

    @Nullable
    @Override
    public GeckolibSpecialRenderer.RenderData getData(ItemStack itemStack) {
        return new RenderData(itemStack.getItem(), itemStack);
    }

    public static class Unbaked implements SpecialModelRenderer.Unbaked {
        public static final MapCodec<GeckolibSpecialRenderer.Unbaked> MAP_CODEC = MapCodec.unit(software.bernie.geckolib.renderer.GeckolibSpecialRenderer.Unbaked::new);

        @Nullable
        @Override
        public SpecialModelRenderer<?> bake(LoadedEntityModels entityModelSet) {
            return new GeckolibSpecialRenderer();
        }

        @Override
        public MapCodec<? extends SpecialModelRenderer.Unbaked> getCodec() {
            return MAP_CODEC;
        }
    }

    public record RenderData(Item item, ItemStack itemstack) {}
}