package software.bernie.geckolib.util;

import org.jetbrains.annotations.ApiStatus;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.object.Color;
import software.bernie.geckolib.renderer.GeoArmorRenderer;

import java.util.function.BiConsumer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/**
 * Internal-only class to store common code mostly for implementation purposes.
 * <p>
 * Shouldn't be used by dependent mods
 */
@ApiStatus.Internal
public class InternalUtil {
    /**
     * Attempt to render a GeckoLib {@link GeoArmorRenderer armor piece} for the given slot
     * <p>
     * This is typically only called by an internal mixin
     *
     * @return true if the armor piece was a GeckoLib armor piece and rendered
     */
    public static <E extends LivingEntity, S extends BipedEntityRenderState, M extends BipedEntityModel<S>, A extends BipedEntityModel<S>> boolean tryRenderGeoArmorPiece(
            MatrixStack poseStack, VertexConsumerProvider bufferSource, E entity, ItemStack stack, EquipmentSlot equipmentSlot,
            M parentModel, A baseModel, float partialTick, int packedLight, float netHeadYaw, float headPitch, BiConsumer<A, EquipmentSlot> partVisibilitySetter) {
        final Item item = stack.getItem();
        final EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);

        if (equippable == null || equippable.slot() != equipmentSlot)
            return false;

        final BipedEntityModel<?> geckolibModel = GeoRenderProvider.of(item).getGeoArmorRenderer(entity, stack, equipmentSlot,
                equipmentSlot == EquipmentSlot.LEGS ? EquipmentModel.LayerType.HUMANOID_LEGGINGS : EquipmentModel.LayerType.HUMANOID, baseModel);

        if (geckolibModel == null)
            return false;

        parentModel.copyTransforms(baseModel);
        partVisibilitySetter.accept(baseModel, equipmentSlot);

        if (geckolibModel instanceof GeoArmorRenderer<?> geoArmorRenderer)
            geoArmorRenderer.prepForRender(entity, stack, equipmentSlot, baseModel, bufferSource, partialTick, netHeadYaw, headPitch);

        baseModel.copyTransforms((A)geckolibModel);
        geckolibModel.render(poseStack, null, packedLight, OverlayTexture.DEFAULT_UV, Color.WHITE.argbInt());

        return true;
    }
}
