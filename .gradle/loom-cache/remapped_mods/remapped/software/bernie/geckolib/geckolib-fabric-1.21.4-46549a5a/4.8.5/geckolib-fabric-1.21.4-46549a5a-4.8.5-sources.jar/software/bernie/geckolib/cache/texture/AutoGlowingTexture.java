package software.bernie.geckolib.cache.texture;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.Pair;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.GeckoLibServices;
import software.bernie.geckolib.resource.GeoGlowingTextureMeta;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.TextureContents;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.TriState;
import net.minecraft.util.Util;

/**
 * Texture object type responsible for GeckoLib's emissive render textures
 *
 * @see <a href="https://github.com/bernie-g/geckolib/wiki/Emissive-Textures-Glow-Layer">GeckoLib Wiki - Glow Layers</a>
 */
public class AutoGlowingTexture extends GeoAbstractTexture {
	private static final RenderPhase.ShaderProgram SHADER_STATE = new RenderPhase.ShaderProgram(ShaderProgramKeys.RENDERTYPE_ENTITY_TRANSLUCENT_EMISSIVE);
	private static final RenderPhase.Transparency TRANSPARENCY_STATE = new RenderPhase.Transparency("translucent_transparency", () -> {
		RenderSystem.enableBlend();
		RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
	}, () -> {
		RenderSystem.disableBlend();
		RenderSystem.defaultBlendFunc();
	});
	private static final RenderPhase.WriteMaskState WRITE_MASK = new RenderPhase.WriteMaskState(true, true);
	private static final BiFunction<Identifier, Boolean, RenderLayer> GLOWING_RENDER_TYPE = Util.memoize((texture, isGlowing) -> {
		RenderPhase.Texture textureState = new RenderPhase.Texture(texture, TriState.FALSE, false);

		return RenderLayer.of("geo_glowing_layer", VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL, VertexFormat.DrawMode.QUADS, 256, false, true,
				class_1921.class_4688.method_23598()
						.method_34578(SHADER_STATE)
						.method_34577(textureState)
						.method_23615(TRANSPARENCY_STATE)
						.method_23611(new RenderPhase.Overlay(true))
						.method_23616(WRITE_MASK).method_23617(isGlowing));
	});
	private static final String APPENDIX = "_glowmask";
	/**
	 * Set to true <u><b>IN DEV</b></u> to have GeckoLib print out the base texture and generated glowlayer textures to the base game directory (./run)
	 */
	public static boolean PRINT_DEBUG_IMAGES = false;

	protected final Identifier textureBase;

	public AutoGlowingTexture(Identifier originalLocation, Identifier location) {
		super(location);

		this.textureBase = originalLocation;
	}

	/**
	 * Get the emissive resource equivalent of the input resource path
	 * <p>
	 * Additionally prepares the texture manager for the missing texture if the resource is not present
	 *
	 * @return The glowlayer resourcepath for the provided input path
	 */
	public static Identifier getEmissiveResource(Identifier baseResource) {
		Identifier path = appendToPath(baseResource, APPENDIX);

		generateTexture(path, textureManager -> textureManager.registerTexture(path, new AutoGlowingTexture(baseResource, path)));

		return path;
	}

	/**
	 * Generates the glow layer {@link NativeImage} and appropriately modifies the base texture for use in glow render layers
	 */
	@Override
	protected TextureContents loadTexture(ResourceManager resourceManager, MinecraftClient mc) throws IOException {
		Resource baseTextureResource = resourceManager.getResourceOrThrow(this.textureBase);
		Optional<Resource> glowmaskResource = resourceManager.getResource(resourceId());
		AbstractTexture baseTexture = mc.getTextureManager().getTexture(this.textureBase);
		NativeImage baseImage = baseTexture instanceof DynamicTexture dynamicTexture ? dynamicTexture.getPixels() : null;
		ResourceMetadata baseTextureMeta = baseTextureResource.metadata();
		TextureMetadataSection baseTextureMetaSection = baseTextureMeta.getSection(TextureMetadataSection.TYPE).orElse(null);

		if (baseImage == null) {
			try (InputStream stream = baseTextureResource.open()) {
				baseImage = NativeImage.read(stream);
			}
		}

		NativeImage referenceImage = baseImage;
		Pair<NativeImage, GeoGlowingTextureMeta> contents = glowmaskResource.map(resource -> {
			NativeImage image;

			try (InputStream stream = resource.open()) {
				image = NativeImage.read(stream);
			}
			catch (IOException e) {
                throw new RuntimeException(e);
            }

            return Pair.of(image, GeoGlowingTextureMeta.fromExistingImage(image));
        }).orElseGet(() -> {
			return Pair.of(new NativeImage(referenceImage.getWidth(), referenceImage.getHeight(), true),
					baseTextureMeta.getSection(GeoGlowingTextureMeta.TYPE).orElseGet(() -> {
						GeckoLibConstants.LOGGER.error("Attempting to use a glowmask but no glowmask or .png.mcmeta was found for texture: {}", this.textureBase);

						return new GeoGlowingTextureMeta(List.of());
					}));
		});

		contents.right().createImageMask(referenceImage, contents.left());

		if (PRINT_DEBUG_IMAGES && GeckoLibServices.PLATFORM.isDevelopmentEnvironment()) {
			printDebugImageToDisk(this.textureBase, referenceImage);
			printDebugImageToDisk(resourceId(), contents.left());
		}

		switch (baseTexture) {
			case ReloadableTexture reloadable -> reloadable.apply(new TextureContents(referenceImage, baseTextureMetaSection));
			case DynamicTexture dynamicTexture -> dynamicTexture.upload();
			default -> uploadTexture(baseTexture, new TextureContents(referenceImage, baseTextureMetaSection));
		}

		return new TextureContents(contents.left(), baseTextureMetaSection);
	}

	/**
	 * Return a cached instance of the RenderType for the given texture for AutoGlowingGeoLayer rendering
	 *
	 * @param texture The texture of the resource to apply a glow layer to
	 */
	public static RenderLayer getRenderType(Identifier texture) {
		return GLOWING_RENDER_TYPE.apply(getEmissiveResource(texture), false);
	}

	/**
	 * Return a cached instance of the RenderType for the given texture for AutoGlowingGeoLayer rendering, while the entity has an outline
	 *
	 * @param texture The texture of the resource to apply a glow layer to
	 */
	public static RenderLayer getOutlineRenderType(Identifier texture) {
		return GLOWING_RENDER_TYPE.apply(getEmissiveResource(texture), true);
	}
}
