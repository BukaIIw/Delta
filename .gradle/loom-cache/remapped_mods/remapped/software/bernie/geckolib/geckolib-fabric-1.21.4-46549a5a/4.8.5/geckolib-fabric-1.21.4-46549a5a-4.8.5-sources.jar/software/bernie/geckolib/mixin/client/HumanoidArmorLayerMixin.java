package software.bernie.geckolib.mixin.client;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import software.bernie.geckolib.renderer.GeoEntityRenderState;
import software.bernie.geckolib.util.InternalUtil;

/**
 * Injection into the render point for armour on HumanoidModels (Players, Zombies, etc) to defer to GeckoLib item-armor rendering as applicable
 * <p>
 * Does nothing if GeckoLib has nothing to handle for the given arguments
 */
@Mixin(ArmorFeatureRenderer.class)
public abstract class HumanoidArmorLayerMixin<S extends BipedEntityRenderState, M extends BipedEntityModel<S>, A extends BipedEntityModel<S>> {
    @Shadow
    protected abstract void setPartVisibility(A baseModel, EquipmentSlot equipmentSlot);

    @WrapWithCondition(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V",
            require = 0,
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/entity/layers/HumanoidArmorLayer;renderArmorPiece(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;ILnet/minecraft/client/model/HumanoidModel;)V"))
    public boolean geckolib$wrapArmorPieceRender(ArmorFeatureRenderer<S, M, A> renderLayer, MatrixStack poseStack, VertexConsumerProvider bufferSource, ItemStack stack, EquipmentSlot equipmentSlot, int packedLight, A baseModel,
                                                 MatrixStack poseStack2, VertexConsumerProvider bufferSource2, int packedLight2, S humanoidRenderState, float netHeadYaw, float headPitch) {
        final GeoEntityRenderState geoRenderState = (GeoEntityRenderState)humanoidRenderState;

        return !InternalUtil.tryRenderGeoArmorPiece(poseStack, bufferSource, (LivingEntity)geoRenderState.geckolib$getEntity(), stack, equipmentSlot, renderLayer.getContextModel(), baseModel,
                geoRenderState.geckolib$getPartialTick(), packedLight, netHeadYaw, headPitch, this::setPartVisibility);
    }

    @WrapWithCondition(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V",
            require = 0,
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/entity/layers/HumanoidArmorLayer;renderArmorPiece(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;ILnet/minecraft/client/model/HumanoidModel;Lnet/minecraft/client/renderer/entity/state/HumanoidRenderState;)V", remap = false))
    public boolean geckolib$wrapArmorPieceRenderForge(ArmorFeatureRenderer<S, M, A> renderLayer, MatrixStack poseStack, VertexConsumerProvider bufferSource, ItemStack stack, EquipmentSlot equipmentSlot, int packedLight, A baseModel,
                                                      S humanoidRenderState, MatrixStack poseStack2, VertexConsumerProvider bufferSource2, int packedLight2, S humanoidRenderState2, float netHeadYaw, float headPitch) {
        final GeoEntityRenderState geoRenderState = (GeoEntityRenderState)humanoidRenderState;

        return !InternalUtil.tryRenderGeoArmorPiece(poseStack, bufferSource, (LivingEntity)geoRenderState.geckolib$getEntity(), stack, equipmentSlot, renderLayer.getContextModel(), baseModel,
                geoRenderState.geckolib$getPartialTick(), packedLight, netHeadYaw, headPitch, this::setPartVisibility);
    }
}