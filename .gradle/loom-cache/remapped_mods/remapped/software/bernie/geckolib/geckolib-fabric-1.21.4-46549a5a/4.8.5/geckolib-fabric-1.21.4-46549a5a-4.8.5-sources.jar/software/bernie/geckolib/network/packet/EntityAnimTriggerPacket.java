package software.bernie.geckolib.network.packet;

import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.GeckoLibConstants;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.GeoReplacedEntity;
import software.bernie.geckolib.util.ClientUtil;
import software.bernie.geckolib.util.RenderUtil;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

public record EntityAnimTriggerPacket(int entityId, boolean isReplacedEntity, Optional<String> controllerName, String animName) implements MultiloaderPacket {
    public static final CustomPayload.Id<EntityAnimTriggerPacket> TYPE = new Id<>(GeckoLibConstants.id("entity_anim_trigger"));
    public static final PacketCodec<PacketByteBuf, EntityAnimTriggerPacket> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, EntityAnimTriggerPacket::entityId,
            PacketCodecs.BOOLEAN, EntityAnimTriggerPacket::isReplacedEntity,
            PacketCodecs.STRING.collect(PacketCodecs::optional), EntityAnimTriggerPacket::controllerName,
            PacketCodecs.STRING, EntityAnimTriggerPacket::animName,
            EntityAnimTriggerPacket::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return TYPE;
    }

    @Override
    public void receiveMessage(@Nullable PlayerEntity sender, Consumer<Runnable> workQueue) {
        workQueue.accept(() -> {
            Entity entity = ClientUtil.getLevel().getEntityById(this.entityId);

            if (entity == null)
                return;

            if (!this.isReplacedEntity) {
                if (entity instanceof GeoEntity geoEntity)
                    geoEntity.triggerAnim(this.controllerName.orElse(null), this.animName);

                return;
            }

            if (RenderUtil.getReplacedAnimatable(entity.getType()) instanceof GeoReplacedEntity replacedEntity)
                replacedEntity.triggerAnim(entity, this.controllerName.orElse(null), this.animName);
        });
    }
}
